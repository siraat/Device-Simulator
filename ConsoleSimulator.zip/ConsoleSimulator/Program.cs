﻿using System;
using System.IO;
using Google.Protobuf; 
using Google.Protobuf.WellKnownTypes;
using Input; 

public partial class Program
{
    public static void Main(string[] args)
    {
        string filePath = "tracker_data.dat";

        Tracker originalTracker = new Tracker
        {
            Time = Timestamp.FromDateTime(DateTime.UtcNow), 
            MonitorSerialNumber = 12345,
            Temperature = 25, 
            Humidity = 45,   
            Lat = 3405223,    
            Long = -11824368  
        };

        Console.WriteLine("Original Tracker data:");
        Console.WriteLine(originalTracker.ToString());
        Console.WriteLine();

        using (var output = File.Create(filePath))
        {
            originalTracker.WriteTo(output);
        }
        Console.WriteLine($"Tracker data serialized to {filePath}");
        Console.WriteLine();

        Tracker deserializedTracker;
        using (var input = File.OpenRead(filePath))
        {
            deserializedTracker = Tracker.Parser.ParseFrom(input);
        }

        Console.WriteLine("Deserialized Tracker data from file:");
        Console.WriteLine(deserializedTracker.ToString());

    }
}

