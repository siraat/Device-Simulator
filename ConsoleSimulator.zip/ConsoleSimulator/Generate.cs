using System;
using System.IO;
using Google.Protobuf; 
using System.Threading; 
using Google.Protobuf.WellKnownTypes;
using System.Text.Json;
using System.Collections.Generic;
using Input; 

public class Generate
{

    public static void Main(string[] args)
    {
        Console.WriteLine("Tracker Message Generator");
        //Console.Write("Enter the number of devices to simulate: ");
        string jsonFilePath = "userInput.json";
        List<DeviceSetting>? deviceConfigs;
        string jsonInfo = File.ReadAllText(jsonFilePath);
        deviceConfigs = JsonSerializer.Deserialize<List<DeviceSetting>>(File.ReadAllText(jsonFilePath));
        Random random = new Random();

        foreach (var device in deviceConfigs){
            Console.WriteLine($"\nSimulating Device Serial Number: {device.SerialNumber}");
            Console.WriteLine($"  Messages to send: {device.NumberOfMessages}");
            Console.WriteLine($"  Delay between messages: {device.Delay} seconds");
        
        // string? input = Console.ReadLine();
        // int numberOfDevices = int.Parse(input); 
        // // Console.Write("How many messages per device? ");
        // // string? messageInput = Console.ReadLine();
        // // int numberOfMessages = int.Parse(messageInput);

        
        // const int delayMilliseconds = 10000; 
        // Console.WriteLine("\nMessage 1: ");
        // for (int i = 0; i < numberOfDevices; i++)
        // {
        //     int id = i + 1;

        //     Tracker trackerMessage = createTracker(id);

        //     Console.WriteLine($"Tracker Data for Device {id}, Message 1");
        //     Console.WriteLine(trackerMessage.ToString());
        //     Console.WriteLine();
        // }
            for (int msgNum = 0; msgNum < device.NumberOfMessages; msgNum++)
            {
                int message = msgNum + 1;
                Console.WriteLine($"\nGenerating Message {message} for Device {device.SerialNumber}...");

                Tracker trackerMessage = createTracker(device.SerialNumber);

                Console.WriteLine($"--- Tracker Data (Device {device.SerialNumber}, Message {message}) ---");
                Console.WriteLine(trackerMessage.ToString());

                if (msgNum < device.NumberOfMessages - 1)
                {
                    int currentDelayMilliseconds = device.Delay * 1000;
                    Console.WriteLine($"\nNext message for Device {device.SerialNumber} in {device.Delay} seconds...");
                    for (int s = device.Delay; s > 0; s--)
                    {
                        Console.Write($"\rWaiting... {s}s   ");
                        Thread.Sleep(1000);
                    }
                    Console.WriteLine("\rWaiting... 0s   ");
                }
            }
        }
             
    }    


    public static Tracker createTracker(int currentDeviceId){
        Random random = new Random();
        Tracker create = new Tracker{
            Time = Timestamp.FromDateTime(DateTime.UtcNow),
            MonitorSerialNumber = currentDeviceId, 
            Temperature = random.Next(0, 81),             
            Humidity = random.Next(0, 101),                 
            Lat = random.Next(10000, 30000), 
            Long = random.Next(10000, 30000)
        };
        return create;
    }

    public class DeviceSetting
    {
        public int SerialNumber { get; set; }
        public int Delay { get; set; } 
        public int NumberOfMessages { get; set; }
    }
    
}
